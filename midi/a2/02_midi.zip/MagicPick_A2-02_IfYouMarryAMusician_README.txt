Magic Pick - Act 2 - If You Marry A Musician
Guitar-synth MIDI from the Ableton set, printed through each track's MIDI effects
(MIDI Thinner, then Note Length) - the notes those tracks actually send out.

Every file starts at the 2-bar count-in (Ableton bar 109|1) and ends at bar 192|1,
so it lines up with the Band audio from the rehearsal site when both start at bar 1.
Tempo and time-signature changes are included in each file.

_1st .. _6th   one guitar string each, on MIDI channel 1 (1st, high E) .. 6 (6th, low E)
_strings       all six strings in one file, one track per string, channels 1-6
_syn1          the Syn1 synth part (channel 7)
